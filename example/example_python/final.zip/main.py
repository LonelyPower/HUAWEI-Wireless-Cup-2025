import function
if __name__ == '__main__':
    function.func()